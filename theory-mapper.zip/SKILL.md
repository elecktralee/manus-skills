---
name: theory-mapper
description: "Mapeia a evolução teórica, histórico de estudos, controvérsias e impacto acadêmico de um tema, utilizando referências bibliográficas e datas. Complementa a habilidade 'academic-researcher'. Use para: analisar a trajetória de uma teoria, identificar estudos de replicação, e avaliar a relevância temporal de pesquisas."
---

# Theory Mapper

Esta habilidade permite ao Manus analisar a trajetória de conceitos, teorias e descobertas científicas ao longo do tempo, identificando padrões de desenvolvimento, pontos de inflexão e o impacto de estudos específicos.

## Funcionalidades Principais

-   **Mapeamento Temporal**: Organiza artigos e referências por data de publicação para visualizar a evolução cronológica de um tema.
-   **Identificação de Controvérsias**: Detecta estudos de replicação, falhas de replicação e debates acadêmicos, destacando as diferentes abordagens e resultados.
-   **Análise de Impacto**: Avalia a relevância de artigos com base em citações, periódicos de publicação e a influência subsequente na literatura.
-   **Rastreamento de Linhas de Pesquisa**: Conecta estudos que se referenciam mutuamente para construir uma rede de conhecimento e identificar as principais linhas de pesquisa.

## Interação com 'Academic Researcher'

Esta habilidade é projetada para trabalhar em conjunto com a `academic-researcher`. A `academic-researcher` será utilizada para a **coleta inicial** de artigos e referências das bases de dados. Uma vez que os artigos são identificados e, se possível, seus metadados (datas, citações, resumos) são extraídos, a `theory-mapper` entra em ação para **processar e analisar** essa informação.

## Fluxo de Trabalho de Análise de Evolução Teórica

1.  **Coleta de Dados (via 'academic-researcher')**: Utilize a `academic-researcher` para buscar artigos relevantes sobre um tema específico, coletando o máximo de metadados possível (título, autores, ano, periódico, resumo, número de citações, DOI).
2.  **Organização Cronológica**: Ordene os artigos por data de publicação para estabelecer uma linha do tempo.
3.  **Análise de Conexões**: Identifique citações cruzadas entre os artigos para mapear a influência e o desenvolvimento das ideias.
4.  **Detecção de Replicação e Controvérsias**: Busque por artigos que explicitamente mencionam estudos de replicação, falhas de replicação ou que apresentem resultados conflitantes.
5.  **Avaliação de Impacto**: Considere o número de citações, o fator de impacto do periódico e a recepção da comunidade científica para determinar a relevância e o impacto de cada estudo.
6.  **Síntese e Relatório**: Gere um relatório ou uma visualização que apresente a evolução do tema, os principais marcos, as controvérsias e os estudos mais influentes, com base nas referências analisadas.

## Comandos Úteis (Pseudocódigo para o Manus)

-   `mapear_evolucao(lista_de_artigos)`: Processa uma lista de artigos (com metadados) para gerar uma linha do tempo e análise de impacto.
-   `identificar_controversias(lista_de_artigos)`: Analisa artigos para encontrar evidências de replicação ou resultados conflitantes.
-   `gerar_relatorio_historico(analise_de_dados)`: Compila os resultados da análise em um formato de relatório estruturado.
