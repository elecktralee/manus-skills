# Domínios Acadêmicos para Busca Direcionada

Use estes domínios com o operador `site:` para restringir buscas:

| Plataforma | Domínio Principal |
| :--- | :--- |
| Google Scholar | scholar.google.com |
| PubMed | pubmed.ncbi.nlm.nih.gov |
| SciELO | scielo.br / scielo.org |
| Scopus | scopus.com |
| Web of Science | webofscience.com |
| CAPES Periódicos | periodicos.capes.gov.br |
| Cochrane Library | cochranelibrary.com |
| JSTOR | jstor.org |
| CNKI | cnki.net |
| Medline (via NLM) | nlm.nih.gov |
